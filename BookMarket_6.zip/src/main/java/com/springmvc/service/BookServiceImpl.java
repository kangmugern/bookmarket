package com.springmvc.service;
import java.util.ArrayList;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.domain.Book;
import com.springmvc.repository.BookRepository;
import com.springmvc.repository.BookRowMapper;

@Service
public class BookServiceImpl implements BookService{
	 @Autowired
	 private BookRepository bookRepository;
	 
	 private JdbcTemplate template;

	    @Autowired
	    public void setTemplate(JdbcTemplate template) {
	        this.template = template;
	    }
	 
	 public List<Book> getAllBookList() { 
	        // TODO Auto-generated method stub
		 return bookRepository.getAllBookList();
	 } 
	 
	 
	 public List<Book> getBookListByCategory(String category) {  
	      List<Book> booksByCategory = bookRepository.getBookListByCategory(category);  
	      return booksByCategory;  
	 }  
	 
	 public Set<Book> getBookListByFilter(Map<String, List<String>> filter) {
	      Set<Book> booksByFilter = bookRepository.getBookListByFilter(filter); 
	      return booksByFilter;
	 }
	 
	 public Book getBookById(String bookId) {
	        Book bookById = bookRepository.getBookById(bookId);
	        return bookById;
	 }
	 
	 public void setNewBook(Book book) {  
	        bookRepository.setNewBook(book);  
	 }  
	 public void setUpdateBook(Book book) {  
	        bookRepository.setUpdateBook(book);
	 } 
	 
	  public void setDeleteBook(String bookID) { 
	        bookRepository.setDeleteBook(bookID);
	  }	  
	  public List<Book> searchBooks(String keyword) {
		    String SQL = "SELECT * FROM book WHERE b_name LIKE ? OR b_author LIKE ?";
		    String parameterizedKeyword = "%" + keyword + "%";

		    System.out.println("Debug SQL: " + SQL);
		    System.out.println("Debug parameterizedKeyword: " + parameterizedKeyword);

		    return template.query(SQL, new Object[]{parameterizedKeyword, parameterizedKeyword}, new BookRowMapper());
		}
	  
}
